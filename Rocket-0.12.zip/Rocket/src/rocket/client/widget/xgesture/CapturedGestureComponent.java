package rocket.client.widget.xgesture;

import rocket.client.util.ObjectHelper;

/**
 * Each instance of this class represent part of a complete Gesture. 
 * Gestures are defined as a series of lines or changes in direction of a moving mouse.
 * @author Miroslav Pokorny (mP)
 */
public class CapturedGestureComponent {
	private Direction direction;

	public Direction getDirection() {
		ObjectHelper.checkNotNull("field:description", direction);
		return direction;
	}

	public void setDescription(final Direction direction) {
		ObjectHelper.checkNotNull("field:direction", direction);
		this.direction = direction;
	}

	/**
	 * The x coordinate of the mouse at the start of the gesture component
	 */
	private int startX;

	public int getStartX() {
		return this.startX;
	}

	public void setStartX(final int startX) {
		this.startX = startX;
	}

	/**
	 * The y coordinate of the mouse at the start of the gesture component
	 */
	private int startY;

	public int getStartY() {
		return this.startY;
	}

	public void setStartY(final int startY) {
		this.startY = startY;
	}

	/**
	 * The state of the mouse buttons at the start of the gesture component
	 */
	private MouseButton startMouseButton;
	
	public MouseButton getStartMouseButton(){
		ObjectHelper.checkNotNull("field:startMouseButton", startMouseButton );
		return startMouseButton;
	}
	public void setStartMouseButton(final MouseButton startMouseButton ){
		ObjectHelper.checkNotNull("parameter:startMouseButton", startMouseButton );
		this.startMouseButton = startMouseButton;
	}
	
	/**
	 * The x coordinate of the mouse at the end of the gesture component
	 */
	private int endX;

	public int getEndX() {
		return this.endX;
	}

	public void setEndX(final int endX) {
		this.endX = endX;
	}
	/**
	 * The y coordinate of the mouse at the end of the gesture component
	 */	
	private int endY;

	public int getEndY() {
		return this.endY;
	}

	public void setEndY(final int endY) {
		this.endY = endY;
	}

	/**
	 * The state of the mouse buttons at the end of the gesture component
	 */
	private MouseButton endMouseButton;
	
	public MouseButton getEndMouseButton(){
		ObjectHelper.checkNotNull("field:endMouseButton", endMouseButton );
		return endMouseButton;
	}
	public void setEndMouseButton(final MouseButton endMouseButton ){
		ObjectHelper.checkNotNull("parameter:endMouseButton", endMouseButton );
		this.endMouseButton = endMouseButton;
	}
}
