package rocket.client.widget.xgesture;

import rocket.client.util.StringHelper;

/**
 * Simple enum used to represent a single mouse click.
 * @author Miroslav Pokorny (mP)
 */
public class MouseButton {
	public final static MouseButton NONE = new MouseButton( "None");
	public final static MouseButton LEFT_BUTTON_CLICK = new MouseButton( "LeftClick");
	public final static MouseButton MIDDLE_BUTTON_CLICK = new MouseButton( "MiddleClick");
	public final static MouseButton RIGHT_BUTTON_CLICK = new MouseButton( "RightClick");
	
	private MouseButton( final String description ){
		this.setDescription( description );
	}
	
	private String description;
	
	public String getDescription(){
		StringHelper.checkNotEmpty("field:description", description);
		return description;
	}
	
	protected void setDescription( final String description ){
		StringHelper.checkNotEmpty("parameter:description", description);
		this.description = description;
	}

	public String toString(){
		return description;
	}
}
