package rocket.client.widget.xgesture;

import java.util.ArrayList;
import java.util.List;

import rocket.client.util.ObjectHelper;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventPreview;

/**
 * This watcher attempts to find any gestures and notifies listeners.
 * 
 * @author Miroslav Pokorny (mP)
 */
public class GestureRecorder implements EventPreview {

	public GestureRecorder() {
		this.createCapturedGestureComponents();
	}

	public boolean onEventPreview(final Event event) {
		ObjectHelper.checkNotNull("parameter:event", event);

		//while (true) {
			final int eventType = DOM.eventGetType(event);
			if (eventType == Event.ONCLICK || eventType == Event.ONMOUSEMOVE) {
				this.handleMouseMove( event );
			}
		//}
		return true;
	}

	protected void handleMouseClick(final Event event) {

	}

	protected void handleMouseMove(final Event event) {

	}

	/**
	 * The minimum distance the mouse must move before the watcher records a new
	 * direction move.
	 * 
	 * The value should not be too small otherwise too many events will be
	 * recorded.
	 */
	private int delta;

	public int getDelta() {
		return this.delta;
	}

	public void setDelta(final int delta) {
		this.delta = delta;
	}

	/**
	 * This list is filled with captured gesture components.
	 * 
	 * TODO write a List that is cyclic and includes a maximum capacity.
	 */
	private List capturedGestureComponents;

	public List getCapturedGestureComponents() {
		ObjectHelper.checkNotNull("field:capturedGestureComponents",
				capturedGestureComponents);
		return this.capturedGestureComponents;
	}

	public void setCapturedGestureComponents(
			final List capturedGestureComponents) {
		ObjectHelper.checkNotNull("parameter:capturedGestureComponents",
				capturedGestureComponents);
		this.capturedGestureComponents = capturedGestureComponents;
	}

	protected void createCapturedGestureComponents() {
		this.setCapturedGestureComponents(new ArrayList());
	}
}
