package rocket.client.widget.xgesture;

import rocket.client.util.StringHelper;

/**
 * A simple enum class of the possible gesture directions.
 * These have been simplified into just the 8 basic directions.
 * @author Miroslav Pokorny (mP)
 */
public class Direction {

	public final static Direction UP = new Direction( "Up");
	public final static Direction UPRIGHT = new Direction( "UpRight");
	public final static Direction RIGHT = new Direction( "Right");
	public final static Direction RIGHTDOWN = new Direction( "RightDown");
	public final static Direction DOWN = new Direction( "Down");
	public final static Direction DOWNLEFT = new Direction( "DownLeft");
	public final static Direction LEFT = new Direction( "Left");
	public final static Direction LEFTUP = new Direction( "LeftUp");
	
	private Direction( final String description ){
		this.setDescription( description );
	}
	
	private String description;
	
	public String getDescription(){
		StringHelper.checkNotEmpty("field:description", description);
		return description;
	}
	
	protected void setDescription( final String description ){
		StringHelper.checkNotEmpty("parameter:description", description);
		this.description = description;
	}

	public String toString(){
		return description;
	}
}
