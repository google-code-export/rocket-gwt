/*
 * Copyright Miroslav Pokorny
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package rocket.collection.client;

import java.util.Iterator;
import java.util.NoSuchElementException;

import rocket.util.client.ObjectHelper;

import com.google.gwt.core.client.GWT;

/**
 * This iterator may be used to skip elements from an underlying iterator via the {@link #skip} method.
 * 
 * @author Miroslav Pokorny (mP)
 */
public abstract class SkippingIterator extends IteratorWrapper implements Iterator {
    public boolean hasNext() {
        return this.findNext();
    }

    /**
     * This is the principal method that controls the read ahead / skipping process.
     * 
     * First it checks if a cached object has been already found and exits if one has been. Otherwise it reads from the wrapped iterator one
     * at a time asking skip if the object should be skipped. This continues until the iterator is exhausted or a non skipped element is
     * found.
     * 
     * A flag is returned indicating whether or not an element was found.
     * 
     * @return
     */
    protected boolean findNext() {
        boolean hasMore = this.hasCache();

        if (false == hasMore) {

            // keep looping until the iterator is exhaused or an element that
            // should not be skipped is found.
            final Iterator iterator = this.getIterator();
            while (true) {
                if (false == iterator.hasNext()) {
                    break;
                }

                final Object next = this.getIterator().next();

                // try next...
                if (this.skip(next)) {
                    continue;
                }

                // found exit!
                this.setCache(next);
                hasMore = true;
                break;
            }
        }
        return hasMore;
    }

    protected abstract boolean skip(Object object);

    public Object next() {
        if (false == findNext()) {
            throw new NoSuchElementException(GWT.getTypeName(this) + " is empty.");
        }
        final Object next = this.getCache();
        this.clearCache();
        return next;
    }

    public void remove() {
        this.getIterator().remove();
    }

    /**
     * This property keeps a cached copy of the element that will be returned by {@link #next()}. This is necessary as {@link #hasNext()}
     * reads ahead finding an element that should not be skipped and stores its value here ready for {@link #next()}.
     */
    private Object cache;

    private boolean cacheSet;

    protected Object getCache() {
        ObjectHelper.checkPropertySet("cache", this, cacheSet);
        return cache;
    }

    protected boolean hasCache() {
        return cacheSet;
    }

    protected void setCache(Object cache) {
        this.cache = cache;
        cacheSet = true;
    }

    protected void clearCache() {
        this.cacheSet = false;
    }

    public String toString() {
        return super.toString() + ", cache: " + cache + ", cacheSet: " + cacheSet;
    }
}
