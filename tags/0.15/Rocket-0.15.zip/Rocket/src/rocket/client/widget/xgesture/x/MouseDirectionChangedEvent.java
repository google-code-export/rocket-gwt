package rocket.client.widget.xgesture.x;

import rocket.client.util.PrimitiveHelper;

/**
 * Each instance represents a change in the mouse.
 * 
 * @author Miroslav Pokorny (mP)
 */
public class MouseDirectionChangedEvent extends MouseEvent{
	/**
	 * THe new mouse direction in radians.
	 */
	private int direction;
	
	public int getDirection(){
		return direction;
	}
	
	public void setDirection( final int direction ){
		this.direction = direction;
	}
	
	/**
	 * The distance the mouse has moved in the new direction
	 */
	private int length;
	
	public int getLength(){
		PrimitiveHelper.checkGreaterThan( "field:length", length, 0 );
		return length;
	}
	
	public void setLength( final int length ){
		PrimitiveHelper.checkGreaterThan( "parameter:length", length, 0 );
		this.length = length;
	}
	
	public String toString(){
		return super.toString() + ", direction: " + direction + ", length: " + length;
	}
}
