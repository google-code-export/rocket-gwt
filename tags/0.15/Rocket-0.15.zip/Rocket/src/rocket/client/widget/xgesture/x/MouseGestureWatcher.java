package rocket.client.widget.xgesture.x;

import java.util.ArrayList;
import java.util.List;

import rocket.client.util.ObjectHelper;
import rocket.client.util.PrimitiveHelper;
import rocket.client.widget.xgesture.MouseState;

/**
 * This watcher is responsible for analysing mouse events and matching defined gestures.
 * @author Miroslav Pokorny (mP)
 *
 */
public class MouseGestureWatcher {
	/**
	 * This event is fired each time a mouse button event occurs.
	 * @param leftButton
	 * @param middleButton
	 * @param rightButton
	 */
	public void onButtonEvent( final boolean leftButton, final boolean middleButton, final boolean rightButton ){
		
	}
	
	/**
	 * This event is fired each time the mouse moves.
	 * @param x
	 * @param y
	 */
	public void onMoveEvent( final int x, final int y ){
		
	}
	
	// PROPERTIES :::::::::::::::::::::::::::::::::::::::
	
	/**
	 * The minimum distance the mouse must move before the watcher records a new
	 * direction move.
	 * 
	 * The value should not be too small otherwise too many events will be
	 * recorded.
	 */
	private int delta;

	public int getDelta() {
		PrimitiveHelper.checkGreaterThan("field:delta", delta, 0);
		return this.delta;
	}

	public void setDelta(final int delta) {
		PrimitiveHelper.checkGreaterThan("parameter:delta", delta, 0);
		this.delta = delta;
	}
	
	/**
	 * This list includes all captured MouseEvents.
	 */
	private List capturedEvents;
	
	public List getCapturedEvents(){
		ObjectHelper.checkNotNull("field:capturedEvents", capturedEvents );
		return this.capturedEvents;
	}
	
	public void setCapturedEvents( final List capturedEvents ){
		ObjectHelper.checkNotNull("parameter:capturedEvents", capturedEvents );
		this.capturedEvents = capturedEvents;
	}
	
	protected void createCapturedEvents(){
		this.setCapturedEvents( new ArrayList() );
	}

	/**
	 * This MouseState the last time the mouseState changed.
	 */
	private MouseState previous;

	protected MouseState getPrevious() {
		ObjectHelper.checkNotNull("field:previous", previous);
		return this.previous;
	}

	protected boolean hasPrevious() {
		return null != this.previous;
	}

	protected void setPrevious(final MouseState previous) {
		ObjectHelper.checkNotNull("parameter:previous", previous);
		this.previous = previous;
	}

	/**
	 * Holds the mouse state before the previous MouseState
	 */
	private MouseState beforePrevious;

	protected MouseState getBeforePrevious() {
		ObjectHelper.checkNotNull("field:beforePrevious", beforePrevious);
		return this.beforePrevious;
	}

	protected boolean hasBeforePrevious() {
		return null != this.beforePrevious;
	}

	protected void setBeforePrevious(final MouseState beforePrevious) {
		ObjectHelper.checkNotNull("parameter:beforePrevious", beforePrevious);
		this.beforePrevious = beforePrevious;
	}
	
	public String toString(){
		return super.toString() +
		", capturedEvents: " + capturedEvents +
		", delta: " + delta + ", previous: " + previous + ", beforePrevious: " + beforePrevious;
	}
}
