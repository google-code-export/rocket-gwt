package rocket.client.widget.xgesture;

import rocket.client.util.ObjectHelper;
import rocket.client.util.PrimitiveHelper;

/**
 * A GestureComponent represents a single part of a complete Gesture definition.
 * 
 * @author Miroslav Pokorny (mP)
 */
public class GestureComponent {
	/**
	 * The direction of this component.
	 */
	private Direction direction;

	public Direction getDirection() {
		ObjectHelper.checkNotNull("field:direction", direction);
		return direction;
	}

	public void setDirection(final Direction direction) {
		ObjectHelper.checkNotNull("parameter:direction", direction);
		this.direction = direction;
	}

	/**
	 * The minimum length or pixels that the mouse must have travelled to match
	 * this gesture.
	 */
	private int minimumLength;

	public int getMinimumLength() {
		PrimitiveHelper.checkIsPositive("field:minimumLength", minimumLength);
		return minimumLength;
	}

	public void setMinimumLength(final int minimumLength) {
		PrimitiveHelper.checkIsPositive("parameter:minimumLength",
				minimumLength);
		this.minimumLength = minimumLength;
	}

	/**
	 * The maximum length or pixels that the mouse must have travelled to match
	 * this gesture.
	 */
	private int maximumLength;

	public int getMaximumLength() {
		PrimitiveHelper.checkIsPositive("field:maximumLength", maximumLength);
		return maximumLength;
	}

	public void setMaximumLength(final int maximumLength) {
		PrimitiveHelper.checkIsPositive("parameter:maximumLength",
				maximumLength);
		this.maximumLength = maximumLength;
	}

	/**
	 * The minimum time that this gesture must have taken.
	 */
	private long minimumTime;

	public long getMinimumTime() {
		PrimitiveHelper.checkIsPositive("field:minimumTime", minimumTime);
		return minimumTime;
	}

	public void setMinimumTime(final long minimumTime) {
		PrimitiveHelper.checkIsPositive("parameter:minimumTime", minimumTime);
		this.minimumTime = minimumTime;
	}

	/**
	 * The maximum time that this gesture must have taken. It ensures that
	 * gesture components are done in within a reasonable time and rather than a
	 * long period of time.
	 */
	private long maximumTime;

	public long getMaximumTime() {
		PrimitiveHelper.checkIsPositive("field:maximumTime", maximumTime);
		return maximumTime;
	}

	public void setMaximumTime(final long maximumTime) {
		PrimitiveHelper.checkIsPositive("parameter:maximumTime", maximumTime);
		this.maximumTime = maximumTime;
	}

	public String toString() {
		return super.toString() + ", direction: " + direction
				+ ", minimumLength: " + minimumLength + ", maximumLength: "
				+ this.maximumLength + ", minimumTime: " + minimumTime
				+ ", maximumTime: " + this.maximumTime;
	}
}
