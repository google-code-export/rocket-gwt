package rocket.client.widget.xgesture;

import java.util.ArrayList;
import java.util.List;

import rocket.client.util.ObjectHelper;
import rocket.client.util.PrimitiveHelper;

import com.google.gwt.user.client.Event;

/**
 * This MouseWatcher watches out and records mouse button clicks and direction changes within a List of MouseStates.
 * 
 * @author Miroslav Pokorny (mP)
 */
public class MouseWatcher{

	public MouseWatcher() {
		createMouseStates();
	}

	/**
	 * Factory method which creats a MouseState object from the given event object.
	 * 
	 * @param event The source mouse event.
	 * @return The created MouseState object.
	 */
	protected MouseState createMouseState(final Event event) {
		ObjectHelper.checkNotNull("parameter:event", event);

		final MouseState mouseState = new MouseState();
		mouseState.set(event);
		mouseState.setTime( System.currentTimeMillis() );
		return mouseState;
	}

	protected void handleMouseButtonEvent(final MouseState mouseState) {
		ObjectHelper.checkNotNull("parameter:mouseState", mouseState);

		final boolean hasPrevious = this.hasPrevious();
		if (false == hasPrevious || false == mouseState.equalsButtons(this.getPrevious())) {

			this.addMouseState(mouseState);
			if (hasPrevious) {
				this.setBeforePrevious(this.getPrevious());
			}
			this.setPrevious(mouseState);
		}
	}

	/**
	 * Checks and notifies if the mouse has moved from its previous location.
	 * If it has a check is made if the mouse has moved enough and if it has a check is made on whether it has changed direction.
	 * @param mouseState
	 */
	protected void handleMouseMoveEvent(final MouseState mouseState) {
		ObjectHelper.checkNotNull("parameter:mouseState", mouseState);

		final boolean hasPrevious = this.hasPrevious();
		if( false == hasPrevious || false == hasBeforePrevious() ){
			this.addMouseState(mouseState);

			if (hasPrevious) {
				this.setBeforePrevious(this.getPrevious());
			}
			this.setPrevious(mouseState);
		} else {

			// since the mouse has moved check if the direction has changed...
			final int minimumDistance = this.getDelta();
			final MouseState previous = this.getPrevious();
			final int distanceBetweenPreviousAndNow = previous.distance(mouseState);
			
			if (distanceBetweenPreviousAndNow >= minimumDistance) {
				final MouseState beforePrevious = this.getBeforePrevious();
				this.setPrevious(mouseState);
				this.setBeforePrevious(previous);

				final Direction currentDirection = mouseState.direction(previous);
				final Direction previousDirection = previous.direction(beforePrevious);

				// direction has changed record mouseState.
				if (currentDirection != previousDirection) {
					this.addMouseState(mouseState );
				}
			}
		}
	}

	/**
	 * This list is filled with captured gesture components.
	 */
	private List mouseStates;

	public List getMouseStates() {
		ObjectHelper.checkNotNull("field:mouseStates", mouseStates);
		return this.mouseStates;
	}

	protected void setMouseStates( final List mouseStates) {
		ObjectHelper.checkNotNull("parameter:mouseStates", mouseStates);
		this.mouseStates = mouseStates;
	}

	protected void createMouseStates() {
		this.setMouseStates(new ArrayList());
	}
	
	protected void addMouseState( final MouseState mouseState ){
		ObjectHelper.checkNotNull("parameter:mouseState", mouseState );
		this.getMouseStates().add( mouseState );
	}

	/**
	 * The minimum distance the mouse must move before the watcher records a new
	 * direction move.
	 * 
	 * The value should not be too small otherwise too many events will be
	 * recorded.
	 */
	private int delta;

	public int getDelta() {
		PrimitiveHelper.checkGreaterThan("field:delta", delta, 0);
		return this.delta;
	}

	public void setDelta(final int delta) {
		PrimitiveHelper.checkGreaterThan("parameter:delta", delta, 0);
		this.delta = delta;
	}

	/**
	 * This MouseState the last time the mouseState changed.
	 */
	private MouseState previous;

	protected MouseState getPrevious() {
		ObjectHelper.checkNotNull("field:previous", previous);
		return this.previous;
	}

	protected boolean hasPrevious() {
		return null != this.previous;
	}

	protected void setPrevious(final MouseState previous) {
		ObjectHelper.checkNotNull("parameter:previous", previous);
		this.previous = previous;
	}

	/**
	 * Holds the mouse state before the previous MouseState
	 */
	private MouseState beforePrevious;

	protected MouseState getBeforePrevious() {
		ObjectHelper.checkNotNull("field:beforePrevious", beforePrevious);
		return this.beforePrevious;
	}

	protected boolean hasBeforePrevious() {
		return null != this.beforePrevious;
	}

	protected void setBeforePrevious(final MouseState beforePrevious) {
		ObjectHelper.checkNotNull("parameter:beforePrevious", beforePrevious);
		this.beforePrevious = beforePrevious;
	}
}