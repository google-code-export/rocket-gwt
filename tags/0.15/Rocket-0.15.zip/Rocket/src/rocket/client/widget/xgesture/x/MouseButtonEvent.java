package rocket.client.widget.xgesture.x;

import rocket.client.util.ObjectHelper;

/**
 * Instances represent a single MouseButton event captured.
 * @author Miroslav Pokorny (mP)
 */
public class MouseButtonEvent extends MouseEvent{
	
	private boolean leftButton;

	private boolean leftButtonSet;

	public boolean isLeftButton() {
		ObjectHelper.checkPropertySet("leftButton", this, this.hasLeftButton());
		return this.leftButton;
	}

	public boolean hasLeftButton() {
		return this.leftButtonSet;
	}

	public void setLeftButton(final boolean leftButton) {
		this.leftButton = leftButton;
		this.leftButtonSet = true;
	}

	private boolean middleButton;

	private boolean middleButtonSet;

	public boolean isMiddleButton() {
		ObjectHelper.checkPropertySet("middleButton", this, this
				.hasMiddleButton());
		return this.middleButton;
	}

	public boolean hasMiddleButton() {
		return this.middleButtonSet;
	}

	public void setMiddleButton(final boolean middleButton) {
		this.middleButton = middleButton;
		this.middleButtonSet = true;
	}

	private boolean rightButton;

	private boolean rightButtonSet;

	public boolean isRightButton() {
		ObjectHelper.checkPropertySet("rightButton", this, this
				.hasRightButton());
		return this.rightButton;
	}

	public boolean hasRightButton() {
		return this.rightButtonSet;
	}

	public void setRightButton(final boolean rightButton) {
		this.rightButton = rightButton;
		this.rightButtonSet = true;
	}

	public String toString(){
		return super.toString() + ", leftButton: " + leftButton + ", middleButton: " + middleButton + ", rightButton: " + rightButton;
	}
}
