package rocket.client.widget.xgesture;

import rocket.client.util.ObjectHelper;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;

/**
 * Represents a snapshot in time of the mouse including its coordinates, button state and timestamp.
 * 
 * @author Miroslav Pokorny (mP)
 */
public class MouseState {
	
	/**
	 * Copy constructor which basically copies all properties from mouseState to its own.
	 * @param mouseState
	 */
	public MouseState( final MouseState otherMouseState ){
		ObjectHelper.checkNotNull("parameter:otherMouseState", otherMouseState );
		
		this.x = otherMouseState.x;
		this.xSet = otherMouseState.xSet;
		this.y = otherMouseState.y;
		this.ySet = otherMouseState.ySet;
		this.leftButton = otherMouseState.leftButton;
		this.leftButtonSet = otherMouseState.leftButtonSet;
		this.middleButton = otherMouseState.middleButton;
		this.middleButtonSet = otherMouseState.middleButtonSet;
		this.rightButton = otherMouseState.rightButton;
		this.rightButtonSet = otherMouseState.rightButtonSet;
	}
	
	public MouseState(){
	}
	
	/**
	 * Returns the distance moved between the start and end coordinates.
	 * @return
	 */
	public int distance( final MouseState otherMouseState ){
		ObjectHelper.checkNotNull("parameter:otherMouseState", otherMouseState );
		
		final int deltaX = otherMouseState.getX() - this.getX();
		final int deltaY = otherMouseState.getY() - this.getY();
		
		return (int) Math.sqrt( deltaX * deltaX + deltaY * deltaY );
	}
	
	/**
	 * Returns the direction between both the start and end mouse states.
	 * @return
	 */
	public Direction direction( final MouseState otherMouseState ){
		ObjectHelper.checkNotNull("parameter:otherMouseState", otherMouseState );
		ObjectHelper.checkNotSame("this", this, "parameter:otherMouseState", otherMouseState );
				
		final int deltaX = otherMouseState.getX() - this.getX();
		final int deltaY = otherMouseState.getY() - this.getY();
		
		return Direction.getDirection( - deltaX, - deltaY );
	}
	
	public void set( final Event event ){
		this.setButtons( event );
		this.setCoordinates( event );
	}

	/**
	 * The x coordinate of the mouse
	 */
	private int x;
	private boolean xSet;

	public int getX() {
		ObjectHelper.checkPropertySet("x", this, hasX());
		return this.x;
	}

	public boolean hasX() {
		return xSet;
	}

	public void setX(final int x) {
		this.x = x;
		this.xSet = true;
	}

	/**
	 * The y coordinate of the mouse
	 */
	private int y;

	private boolean ySet;

	public int getY() {
		ObjectHelper.checkPropertySet("y", this, hasY());
		return this.y;
	}

	public boolean hasY() {
		return ySet;
	}

	public void setY(final int y) {
		this.y = y;
		this.ySet = true;
	}

	/**
	 * Updates the coordinates of this object from the coordinates found within
	 * the event.
	 * 
	 * @param event
	 */
	public void setCoordinates(final Event event) {
		ObjectHelper.checkNotNull("parameter:event", event );
		this.setX(DOM.eventGetClientX(event));
		this.setY(DOM.eventGetClientY(event));
	}

	private boolean leftButton;

	private boolean leftButtonSet;

	public boolean isLeftButton() {
		ObjectHelper.checkPropertySet("leftButton", this, this.hasLeftButton());
		return this.leftButton;
	}

	public boolean hasLeftButton() {
		return this.leftButtonSet;
	}

	public void setLeftButton(final boolean leftButton) {
		this.leftButton = leftButton;
		this.leftButtonSet = true;
	}

	private boolean middleButton;

	private boolean middleButtonSet;

	public boolean isMiddleButton() {
		ObjectHelper.checkPropertySet("middleButton", this, this
				.hasMiddleButton());
		return this.middleButton;
	}

	public boolean hasMiddleButton() {
		return this.middleButtonSet;
	}

	public void setMiddleButton(final boolean middleButton) {
		this.middleButton = middleButton;
		this.middleButtonSet = true;
	}

	private boolean rightButton;

	private boolean rightButtonSet;

	public boolean isRightButton() {
		ObjectHelper.checkPropertySet("rightButton", this, this
				.hasRightButton());
		return this.rightButton;
	}

	public boolean hasRightButton() {
		return this.rightButtonSet;
	}

	public void setRightButton(final boolean rightButton) {
		this.rightButton = rightButton;
		this.rightButtonSet = true;
	}

	/**
	 * The three button properties are updated only if the event is a button
	 * click event.
	 * 
	 * @param event
	 */
	public void setButtons(final Event event) {
		ObjectHelper.checkNotNull("parameter:event", event);

		if (DOM.eventGetType(event) == Event.ONCLICK) {
			final int button = DOM.eventGetButton(event);
			this.setLeftButton(button == Event.BUTTON_LEFT);
			this.setMiddleButton(button == Event.BUTTON_MIDDLE);
			this.setRightButton(button == Event.BUTTON_RIGHT);
		}
	}

	public boolean equals(final Object otherObject) {
		return otherObject instanceof MouseState ? this
				.equals((MouseState) otherObject) : false;
	}

	public boolean equals(final MouseState otherMouseState) {
		return this.equalsCoordinates(otherMouseState)
				&& this.equalsButtons(otherMouseState);
	}

	public boolean equalsCoordinates(final MouseState otherMouseState) {
		ObjectHelper.checkNotNull("parameter:otherMouseState", otherMouseState);

		boolean same = false;
		while (true) {
			if (this.hasX() != otherMouseState.hasX()) {
				break;
			}
			if (this.getX() != otherMouseState.getX()) {
				break;
			}
			if (this.hasY() != otherMouseState.hasY()) {
				break;
			}
			if (this.getY() != otherMouseState.getY()) {
				break;
			}
			same = true;
			break;
		}
		return same;
	}

	public boolean equalsButtons(final MouseState otherMouseState) {
		ObjectHelper.checkNotNull("parameter:otherMouseState", otherMouseState);

		boolean same = false;
		while (true) {
			if (this.hasLeftButton() != otherMouseState.hasLeftButton()) {
				break;
			}
			if (this.isLeftButton() != otherMouseState.isLeftButton()) {
				break;
			}
			if (this.hasMiddleButton() != otherMouseState.hasMiddleButton()) {
				break;
			}
			if (this.isMiddleButton() != otherMouseState.isMiddleButton()) {
				break;
			}
			if (this.hasRightButton() != otherMouseState.hasRightButton()) {
				break;
			}
			if (this.isRightButton() != otherMouseState.isRightButton()) {
				break;
			}
			same = true;
			break;
		}
		return same;
	}

	private long time;

	public long getTime() {
		return this.time;
	}

	public void setTime(final long time) {
		this.time = time;
	}

	
	public String toString() {
		return super.toString() + ", x: " + x + ", y: " + y + ", leftButton: "
				+ leftButton + ", middleButton: " + middleButton
				+ ", rightButton: " + rightButton + ", time: " + time;
	}
}
