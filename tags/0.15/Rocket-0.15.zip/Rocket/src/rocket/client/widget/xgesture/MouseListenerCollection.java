package rocket.client.widget.xgesture;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import rocket.client.util.ObjectHelper;
/**
 * A collection of MouseListeners. Also contains methods to notify listeners of MouseListener events.
 * @author Miroslav Pokorny (mP)
 */
public class MouseListenerCollection {
	
	public MouseListenerCollection(){
		this.createListeners();
	}
	/**
	 * A listeners containing MouseListenerseners
	 */
	private List listeners;

	protected List getListeners() {
		ObjectHelper.checkNotNull("field:listeners", listeners);
		return this.listeners;
	}

	protected void setListeners(final List listeners ) {
		ObjectHelper.checkNotNull("parameter:listeners", listeners);
		this.listeners = listeners;
	}	
	
	protected void createListeners(){
		this.setListeners( new ArrayList() );
	}
	
	public void add( final MouseListener mouseListener ){
		ObjectHelper.checkNotNull( "parameter:mouseListener", mouseListener);
		this.getListeners().add( mouseListener );
	}
	public void remove( final MouseListener mouseListener ){
		ObjectHelper.checkNotNull( "parameter:mouseListener", mouseListener);
		this.getListeners().remove( mouseListener );
	}
	
	public void fireMoved( final MouseState mouseState ){
		ObjectHelper.checkNotNull( "parameter:mouseState", mouseState);
		
		final Iterator listeners = this.getListeners().iterator();
		while( listeners.hasNext() ){
			final MouseListener listener = (MouseListener) listeners.next();
			listener.onMove( mouseState );
		}
	}
	
	public void fireDirectionChanged( final MouseState mouseState, final Direction direction ){
		ObjectHelper.checkNotNull( "parameter:mouseState", mouseState);
		ObjectHelper.checkNotNull( "parameter:direction", direction );
		
		final Iterator listeners = this.getListeners().iterator();
		while( listeners.hasNext() ){
			final MouseListener listener = (MouseListener) listeners.next();
			listener.onDirectionChange( mouseState, direction );
		}
	}
	public void fireButtonChanged( final MouseState mouseState ){
		ObjectHelper.checkNotNull( "parameter:mouseState", mouseState);
		
		final Iterator listeners = this.getListeners().iterator();
		while( listeners.hasNext() ){
			final MouseListener listener = (MouseListener) listeners.next();
			listener.onButtonChange( mouseState );
		}
	}
}
