package rocket.client.widget.xgesture;
/**
 * This interface provides a means to keep track in changes in mouse movement and buttons.
 * @author Miroslav Pokorny (mP)
 *
 */
public interface MouseListener {
	
	/**
	 * THis method is invoked whenever the mouse is moved.
	 * @param mouseState
	 */
	void onMove( MouseState mouseState );
	
	/**
	 * This method is invoked whenever the mouse pointer changes direction.
	 * @param mouseState A mouse state showing when the change of direction occured.
	 * @param direction The new direction.
	 */
	void onDirectionChange( MouseState mouseState, Direction direction );
	
	/**
	 * This method is invoked whenever a mouse button is clicked/released.
	 * @param mouseState
	 */
	void onButtonChange( MouseState mouseState );
}
