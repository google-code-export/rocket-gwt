package rocket.client.widget.xgesture.x;

public abstract class MouseEvent {
	
	protected MouseEvent(){		
	}
	
	private long time;
	
	public long getTime(){
		return time;
	}
	
	public void setTime( final long time ){
		this.time = time;
	}
}
