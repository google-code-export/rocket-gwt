/*
 * Copyright 2006 NSW Police Government Australia
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package rocket.test.widget.textboxtimepicker.client;

import java.util.Date;

import rocket.client.widget.time.TextBoxTimePicker;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ChangeListener;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.KeyboardListener;
import com.google.gwt.user.client.ui.KeyboardListenerAdapter;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class TextBoxTimePickerTest implements EntryPoint {	
	
    /**
     * This is the entry point method.
     */
    public void onModuleLoad() {
        try {
            final RootPanel rootPanel = RootPanel.get();
            rootPanel.add( new HTML("<hr/>"));
            
            final Date date = new Date();
            rootPanel.add( new Label( "Now " + date.toGMTString() ));
            
            rootPanel.add( new HTML("<hr/>"));
            
            final TextBoxTimePicker picker = new TextBoxTimePicker();
            picker.setTime( date.getTime() );
            rootPanel.add(picker);
            
            rootPanel.add( new HTML("<hr/>"));
            
            rootPanel.add( new Label( "Hours"));
            final TextBox hours = new TextBox();
            hours.addKeyboardListener( new KeyboardListenerAdapter(){
            	public void onKeyPress( final Widget widget, final char c, final int modifier){
            		if( c == KeyboardListener.KEY_ENTER ){
            		try{
            			picker.setHours( Integer.parseInt( hours.getText() ));
            		}catch( final Exception caught ){
            			Window.alert( "" + caught );
            		}
            		} // if
            	}
            });
            rootPanel.add( hours );
            
            rootPanel.add( new Label( "Minutes"));
            final TextBox minutes = new TextBox();
            minutes.addKeyboardListener( new KeyboardListenerAdapter(){
            	public void onKeyPress( final Widget widget, final char c, final int modifier){
            		if( c == KeyboardListener.KEY_ENTER ){
            		try{
            			picker.setMinutes( Integer.parseInt( minutes.getText() ));
            		}catch( final Exception caught ){
            			Window.alert( "" + caught );
            		}
            		} // if
            	}
            });
            rootPanel.add( minutes );
            
            rootPanel.add( new Label( "Seconds"));
            final TextBox seconds = new TextBox();
            seconds.addKeyboardListener( new KeyboardListenerAdapter(){
            	public void onKeyPress( final Widget widget, final char c, final int modifier){
            		if( c == KeyboardListener.KEY_ENTER ){
            		try{
            			picker.setSeconds( Integer.parseInt( seconds.getText() ));
            		}catch( final Exception caught ){
            			Window.alert( "" + caught );
            		}
            		} // if
            	}
            });
            rootPanel.add( seconds );
            
            rootPanel.add( new HTML( "<br/>"));
            
            final CheckBox twentyHourMode = new CheckBox( "24 Hour mode?");
            twentyHourMode.addClickListener( new ClickListener(){
            	public void onClick( final Widget widget ){
            		picker.set24HourMode( twentyHourMode.isChecked());
            	}
            });
            rootPanel.add( twentyHourMode );
            
            rootPanel.add( new HTML("<hr/>"));
            
            rootPanel.add( new Label( "TextBoxTimePicker time watcher"));
            final Label timeWatcher = new Label();
            picker.addChangeListener( new ChangeListener(){
            	public void onChange( final Widget ignored ){
            		timeWatcher.setText( "TextBoxTimePicker time has been changed to<br/>" + 
            				" Time: " + picker.getTime() + "<br/>"+
            				" Hours: " + picker.getHours() + "<br/>"+
            				" Minutes:" + picker.getMinutes() + "<br/>"+
            				" Seconds: " + picker.getSeconds() );
            	}
            });
            rootPanel.add( timeWatcher );
            
            rootPanel.add( new HTML( "<hr/>"));
            
            final Button amTimeSetter = new Button( "set TimePicker to 1:23:45 AM");
            amTimeSetter.addClickListener( new ClickListener(){
            	public void onClick( final Widget widget ){
            		picker.setHours( 1 );
            		picker.setMinutes( 23 );
            		picker.setSeconds( 45 );
            	}
            });
            rootPanel.add( amTimeSetter);
            
            final Button pmTimeSetter = new Button( "set TimePicker to 2:35:46 PM");
            pmTimeSetter.addClickListener( new ClickListener(){
            	public void onClick( final Widget widget ){
            		picker.setHours( 14 );
            		picker.setMinutes( 35 );
            		picker.setSeconds( 46 );
            	}
            });
            rootPanel.add( pmTimeSetter);
            
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
