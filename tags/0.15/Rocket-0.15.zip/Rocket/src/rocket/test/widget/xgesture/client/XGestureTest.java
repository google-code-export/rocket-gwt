/*
 * Copyright 2006 NSW Police Government Australia
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package rocket.test.widget.xgesture.client;

import rocket.client.util.ObjectHelper;
import rocket.client.widget.BlockyPixel;
import rocket.client.widget.HorizontalPanel;
import rocket.client.widget.VerticalPanel;
import rocket.client.widget.xgesture.Direction;
import rocket.client.widget.xgesture.MouseListener;
import rocket.client.widget.xgesture.MouseState;
import rocket.client.widget.xgesture.MouseWatcher;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.RootPanel;

public class XGestureTest implements EntryPoint {

	static final int BACKGROUND_COLOR = 0xffffff;

	static final int FOREGROUND_COLOR = 0x000000;

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {

		final int ROWS = 64;
		final int COLUMNS = 64;

		try {
			final RootPanel rootPanel = RootPanel.get();
			final int width = rootPanel.getOffsetWidth();

			final HorizontalPanel panel = new HorizontalPanel();
			rootPanel.add(panel);
			
			final BlockyPixel pixels = new BlockyPixel();
			pixels.setColumns(COLUMNS);
			pixels.setRows(ROWS);
			pixels.setSize(3 * width / 4 + "px", "100%");
			pixels.clear(BACKGROUND_COLOR);
			panel.add(pixels);
			
			final VerticalPanel directionChangesLog = new VerticalPanel();
			directionChangesLog.setWidth(width / 4 + "px");
			panel.add(directionChangesLog);
			
			final MouseWatcher watcher = new MouseWatcher();
			watcher.setDelta(10);
			watcher.addMouseListener(new MouseListener() {

				final int TRAIL_SIZE = 200;

				int[] xCoordinates = new int[TRAIL_SIZE];

				int[] yCoordinates = new int[TRAIL_SIZE];

				int nextSlot = 0;

				public void onMove(MouseState mouseState) {
					try {
						final int previousX = xCoordinates[nextSlot];
						final int previousY = yCoordinates[nextSlot];
						pixels.setColour(previousX, previousY,
								XGestureTest.BACKGROUND_COLOR);

						int x = mouseState.getX();
						int y = mouseState.getY();
						final int width = pixels.getOffsetWidth();
						final int height = pixels.getOffsetHeight();

						if (x >= 0 && x < width && y >= 0 && y < height) {
							x = x * COLUMNS / width;
							y = y * ROWS / height;
							this.xCoordinates[nextSlot] = x;
							this.yCoordinates[nextSlot] = y;
							pixels.setColour(x, y,
									XGestureTest.FOREGROUND_COLOR);

							this.nextSlot = (this.nextSlot + 1) % TRAIL_SIZE;
						}
					} catch (final Exception caught) {
						caught.printStackTrace();
					}
				}

				// TODO log directions compare against one or more gesture definitions.
				// DIRECTION
				// MIN LENGTH
				// MAX LENGTH
				// MIN TIME
				// MAX TIME
				public void onDirectionChange(MouseState mouseState,
						Direction direction) {
					try {
						directionChangesLog.add(new HTML(direction.toString()));
						if (directionChangesLog.getWidgetCount() == 32) {
							directionChangesLog.remove(0);
						}
					} catch (final Exception caught) {
						caught.printStackTrace();
					}
				}

				public void onButtonChange(MouseState mouseState) {
				}
			});

			final Element blockyElement = pixels.getElement();
			DOM.setEventListener(blockyElement, new EventListener(){
				public void onBrowserEvent(final Event event) {
					ObjectHelper.checkNotNull("parameter:event", event);

					final int eventType = DOM.eventGetType(event);
					if (Event.ONMOUSEDOWN == eventType || Event.ONMOUSEUP == eventType) {
						watcher.handleMouseButtonEvent(watcher.createMouseState(event));
					}
					if (Event.ONMOUSEMOVE == eventType) {
						watcher.handleMouseMoveEvent(watcher.createMouseState(event));
					}
				}
			}
			);
			DOM.sinkEvents( blockyElement, Event.MOUSEEVENTS );

		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

}
