package rocket.test.widget;

import junit.framework.TestCase;
import rocket.client.widget.xgesture.Direction;
/**
 * Unittests for the Direction class.
 * @author Miroslav Pokorny (mP)
 *
 */
public class DirectionTestCase extends TestCase {
	public void test0(){
		final int x = 0;
		final int y = 0;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.NONE;
		assertSame( expected, actual );
	}
	
	public void test1(){
		final int x = 10;
		final int y = 0;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHT;
		assertSame( expected, actual );
	}
	public void test2(){
		final int x = 10;
		final int y = -1;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHT;
		assertSame( expected, actual );
	}
	public void test3(){
		final int x = 10;
		final int y = -4;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHT;
		assertSame( expected, actual );
	}
	public void test4(){
		final int x = 10;
		final int y = -6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UPRIGHT;
		assertSame( expected, actual );
	}
	public void test5(){
		final int x = 10;
		final int y = -10;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UPRIGHT;
		assertSame( expected, actual );
	}
	public void test6(){
		final int x = 10;
		final int y = -11;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UPRIGHT;
		assertSame( expected, actual );
	}
	public void test7(){
		final int x = 10;
		final int y = -30;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UP;
		assertSame( expected, actual );
	}
	public void test8(){
		final int x = 1;
		final int y = -10;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UP;
		assertSame( expected, actual );
	}
	public void test9(){
		final int x = 0;
		final int y = -10;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UP;
		assertSame( expected, actual );
	}
	public void test10(){
		final int x = -1;
		final int y = -10;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UP;
		assertSame( expected, actual );
	}
	public void test11(){
		final int x = -4;
		final int y = -10;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.UP;
		assertSame( expected, actual );
	}
	public void test12(){
		final int x = -6;
		final int y = -10;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFTUP;
		assertSame( expected, actual );
	}
	public void test13(){
		final int x = -7;
		final int y = -8;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFTUP;
		assertSame( expected, actual );
	}
	public void test14(){
		final int x = -8;
		final int y = -8;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFTUP;
		assertSame( expected, actual );
	}
	public void test15(){
		final int x = -10;
		final int y = -8;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFTUP;
		assertSame( expected, actual );
	}
	public void test16(){
		final int x = -10;
		final int y = -6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFTUP;
		assertSame( expected, actual );
	}
	public void test17(){
		final int x = -13;
		final int y = -6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFT;
		assertSame( expected, actual );
	}
	public void test18(){
		final int x = -5;
		final int y = -1;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFT;
		assertSame( expected, actual );
	}
	public void test19(){
		final int x = -10;
		final int y = 0;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFT;
		assertSame( expected, actual );
	}
	public void test20(){
		final int x = -10;
		final int y = 1;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.LEFT;
		assertSame( expected, actual );
	}
	public void test21(){
		final int x = 5;
		final int y = 11;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWN;
		assertSame( expected, actual );
	}
	public void test22(){
		final int x = -11;
		final int y = 11;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWNLEFT;
		assertSame( expected, actual );
	}
	public void test23(){
		final int x = -11;
		final int y = 13;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWNLEFT;
		assertSame( expected, actual );
	}
	public void test24(){
		final int x = -5;
		final int y = 11;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWN;
		assertSame( expected, actual );
	}
	public void test25(){
		final int x = -1;
		final int y = 6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWN;
		assertSame( expected, actual );
	}
	public void test26(){
		final int x = 0;
		final int y = 6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWN;
		assertSame( expected, actual );
	}
	public void test27(){
		final int x = 1;
		final int y = 6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.DOWN;
		assertSame( expected, actual );
	}
	public void test28(){
		final int x = 3;
		final int y = 6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHTDOWN;
		assertSame( expected, actual );
	}
	public void test29(){
		final int x = 6;
		final int y = 6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHTDOWN;
		assertSame( expected, actual );
	}
	public void test30(){
		final int x = 7;
		final int y = 6;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHTDOWN;
		assertSame( expected, actual );
	}
	public void test31(){
		final int x = 7;
		final int y = 2;
		final Direction actual = Direction.getDirection( x, y );
		final Direction expected = Direction.RIGHT;
		assertSame( expected, actual );
	}
}
