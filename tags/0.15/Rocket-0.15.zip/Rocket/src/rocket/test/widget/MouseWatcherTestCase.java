package rocket.test.widget;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;
import rocket.client.collection.SkippingIterator;
import rocket.client.util.ObjectHelper;
import rocket.client.widget.xgesture.Direction;
import rocket.client.widget.xgesture.MouseListener;
import rocket.client.widget.xgesture.MouseState;
import rocket.client.widget.xgesture.MouseWatcher;

/**
 * A series of unit tests that simulates Mouse events via moveBy and buttonChanged methods rather than onBrowserEvent.
 * @author Miroslav Pokorny (mP)
 */
public class MouseWatcherTestCase extends TestCase {
	
	public void testWithoutAnyEvents() {
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		final List list =  watcher.getEvents();
		assertTrue( list.isEmpty() );		
	}
	
	public void testSingleClickEvent() {
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		final MouseState leftButtonClicked = new MouseState();
		leftButtonClicked.setX( 0 );
		leftButtonClicked.setY( 0 );
		leftButtonClicked.setLeftButton( true );
		leftButtonClicked.setMiddleButton( false );
		leftButtonClicked.setRightButton( false );
		
		watcher.handleMouseButtonEvent( leftButtonClicked );
		
		final List list =  watcher.getEvents();
		assertFalse( list.isEmpty() );
		
		final Iterator iterator = list.iterator();
		assertEquals( leftButtonClicked, iterator.next() );
		assertFalse( iterator.hasNext() );
	}
	
	public void testClickAndReleaseEvent() {
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		final MouseState leftButtonClicked = new MouseState();
		leftButtonClicked.setX( 0 );
		leftButtonClicked.setY( 0 );
		leftButtonClicked.setLeftButton( true );
		leftButtonClicked.setMiddleButton( false );
		leftButtonClicked.setRightButton( false );
		
		watcher.handleMouseButtonEvent( leftButtonClicked );
		
		final MouseState leftButtonReleased = new MouseState();
		leftButtonReleased.setX( 0 );
		leftButtonReleased.setY( 0 );
		leftButtonReleased.setLeftButton( false );
		leftButtonReleased.setMiddleButton( false );
		leftButtonReleased.setRightButton( false );
		watcher.handleMouseButtonEvent( leftButtonReleased );
		
		final List events =  watcher.getEvents();
		assertFalse( events.isEmpty() );
		
		final Iterator iterator = events.iterator();
		assertEquals( leftButtonClicked, iterator.next() );
		assertEquals( leftButtonReleased, iterator.next() );
		assertFalse( iterator.hasNext() );
	}
	
	public void testClickAndReleaseThenClickAgainEvent() {
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		final MouseState leftButtonClicked = new MouseState();
		leftButtonClicked.setX( 0 );
		leftButtonClicked.setY( 0 );
		leftButtonClicked.setLeftButton( true );
		leftButtonClicked.setMiddleButton( false );
		leftButtonClicked.setRightButton( false );
		
		watcher.handleMouseButtonEvent( leftButtonClicked );
		
		final MouseState leftButtonReleased = new MouseState();
		leftButtonReleased.setX( 0 );
		leftButtonReleased.setY( 0 );
		leftButtonReleased.setLeftButton( false );
		leftButtonReleased.setMiddleButton( false );
		leftButtonReleased.setRightButton( false );
		watcher.handleMouseButtonEvent( leftButtonReleased );
		
		final MouseState middleButtonClicked = new MouseState();
		middleButtonClicked.setX( 0 );
		middleButtonClicked.setY( 0 );
		middleButtonClicked.setLeftButton( false );
		middleButtonClicked.setMiddleButton( true );
		middleButtonClicked.setRightButton( false );
		
		watcher.handleMouseButtonEvent( middleButtonClicked );
		
		final List list =  watcher.getEvents();
		assertFalse( list.isEmpty() );
		
		final Iterator iterator = list.iterator();
		assertEquals( leftButtonClicked, iterator.next() );
		assertEquals( leftButtonReleased, iterator.next() );
		assertEquals( middleButtonClicked, iterator.next() );
		assertFalse( iterator.hasNext() );
	}
	
	public void testSmallMovementsBackAndForthThatAreLessThanDelta() {
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);		
		
		watcher.moveBy( 1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( 0, 1 );
		
		final List events =  watcher.getEvents();
		assertEquals( 3, events.size() );			
	}
	
	public void testManyMovementsWhichEventuallyExceedDelta0() {				
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		watcher.moveBy( 0, 0 );
		watcher.moveBy( 0, 5 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		
		final List events = watcher.getEvents();
		assertEquals( 7 + 1, events.size() );			
	}
	
	public void testManyMovementsWhichEventuallyExceedDelta1() {				
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		watcher.moveBy( 0, 0 );
		watcher.moveBy( 0, 5 );
		
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );

		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );

		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		
		final List events = watcher.getEvents();
		final Iterator directionChanges = new SkippingIterator(){
			protected boolean skip(Object object){
				return object instanceof Object;
			}
		};
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.RIGHT, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFT, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.RIGHT, directionChanges.next() );
		
		assertFalse( directionChanges.hasNext()  );
	}
	
	public void testManyMovementsWhichEventuallyExceedDelta2() {				
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		watcher.moveBy( 0, 0 );
		watcher.moveBy( 0, -5 );
		
		// right
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );

		// right up
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );

		// up
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );

		// up left
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		
		// left
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		
		final Iterator directionChanges = events.getDirectionChangeDirections().iterator();
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.RIGHT, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UPRIGHT, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UP, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFTUP, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFT, directionChanges.next() );
		
		assertFalse( directionChanges.hasNext()  );
	}
	
	
	public void testManyMovementsWithClicksBetweenDirectionChanges() {				
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		watcher.moveBy( 0, 0 );
		watcher.moveBy( 0, 5 );
		
		// right
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		
		watcher.click( true, false, false );

		// right up
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );

		watcher.click( true, false, false );
		
		// up
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );

		// up left
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		
		// left
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		
		final Iterator directionChanges = events.getDirectionChangeDirections().iterator();
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.RIGHT, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UPRIGHT, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UP, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFTUP, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFT, directionChanges.next() );
		
		assertFalse( directionChanges.hasNext()  );
	}
	
	public void testManyMovementsWithClicksInterruptingMovements0() {				
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		watcher.moveBy( 0, 0 );
		watcher.moveBy( 0, 5 );
		
		// right
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		
		watcher.click( true, false, false );
		
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );

		// right up
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		
		watcher.click( true, false, false );
		
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		
		// up
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );

		// up left
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		
		// left
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		
		final Iterator directionChanges = events.getDirectionChangeDirections().iterator();
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.RIGHT, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UPRIGHT, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UP, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFTUP, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFT, directionChanges.next() );
		
		assertFalse( directionChanges.hasNext()  );
	}
	
	public void testManyMovementsWithClicksInterruptingMovements1() {			
		final TestMouseWatcher watcher = createMouseWatcher();
		watcher.setDelta(5);
		
		watcher.moveBy( 0, 0 );
		watcher.moveBy( 0, 5 );
		
		// right
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );
		
		watcher.click( true, false, false );
		
		watcher.moveBy( 1, 0 );
		watcher.moveBy( 1, 0 );

		// right up
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		
		watcher.click( true, false, false );
		watcher.click( false, true, false );
		
		watcher.moveBy( 1, -1 );
		watcher.moveBy( 1, -1 );
		
		// up
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );
		watcher.click( false, false, true );
		watcher.moveBy( 0, -1 );
		watcher.moveBy( 0, -1 );

		// up left
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		watcher.moveBy( -1, -1 );
		
		// left
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		watcher.moveBy( -1, 0 );
		
		final Iterator directionChanges = events.getDirectionChangeDirections().iterator();
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.RIGHT, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UPRIGHT, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.UP, directionChanges.next() );
		
		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFTUP, directionChanges.next() );

		assertTrue( directionChanges.hasNext()  );
		assertSame( Direction.LEFT, directionChanges.next() );
		
		assertFalse( directionChanges.hasNext()  );
	}
	/**
	 * This MouseListener simply captures all reported MouseState event objects.
	 * @author mP
	 */
	class MouseStateCapturerMouseListener implements MouseListener{
		
		MouseStateCapturerMouseListener(){
			this.setButtonChangeMouseStates( new ListWhichDoesntAllowDuplicates() );
			this.setDirectionChangeMouseStates( new ListWhichDoesntAllowDuplicates() );
			this.setDirectionChangeDirections( new ArrayList() );
			this.setMouseStates( new ListWhichDoesntAllowDuplicates() );
			this.setMoveMouseStates( new ListWhichDoesntAllowDuplicates() );				
		}
		
		public void onMove( MouseState mouseState ){
			this.getMoveMouseStates().add( mouseState );
			this.getMouseStates().add( mouseState );
		}
		public void onDirectionChange( MouseState mouseState, final Direction direction ){
			this.getDirectionChangeMouseStates().add( mouseState );
			this.getDirectionChangeDirections().add( direction );
		}
		
		public void onButtonChange( MouseState mouseState ){
			this.getButtonChangeMouseStates().add( mouseState );
			this.getMouseStates().add( mouseState );
		}

		/**
		 * This mouseStates fired only when the Mouse moves.
		 */
		private List moveMouseStates;

		public List getMoveMouseStates() {
			ObjectHelper.checkNotNull("field:moveMouseStates", moveMouseStates);
			return this.moveMouseStates;
		}

		protected void setMoveMouseStates(final List moveMouseStates ) {
			ObjectHelper.checkNotNull("parameter:moveMouseStates", moveMouseStates);
			this.moveMouseStates = moveMouseStates;
		}	
		
		/**
		 * The captured MouseStates that are received by this MouseListener's onDirectionChange method
		 */
		private List directionChangeMouseStates;

		public List getDirectionChangeMouseStates() {
			ObjectHelper.checkNotNull("field:directionChangeMouseStates", directionChangeMouseStates);
			return this.directionChangeMouseStates;
		}

		protected void setDirectionChangeMouseStates(final List directionChangeMouseStates ) {
			ObjectHelper.checkNotNull("parameter:directionChangeMouseStates", directionChangeMouseStates);
			this.directionChangeMouseStates = directionChangeMouseStates;
		}	

		/**
		 * The captured directions that are received by this MouseListener's onDirectionChange method
		 */
		private List directionChangeDirections;

		public List getDirectionChangeDirections() {
			ObjectHelper.checkNotNull("field:directionChangeDirections", directionChangeDirections);
			return this.directionChangeDirections;
		}

		protected void setDirectionChangeDirections(final List directionChangeDirections ) {
			ObjectHelper.checkNotNull("parameter:directionChangeDirections", directionChangeDirections);
			this.directionChangeDirections = directionChangeDirections;
		}	
		
		/**
		 * This mouseStates fired only when the Mouse buttons change
		 */
		private List buttonChangeMouseStates;

		public List getButtonChangeMouseStates() {
			ObjectHelper.checkNotNull("field:buttonChangeMouseStates", buttonChangeMouseStates);
			return this.buttonChangeMouseStates;
		}

		protected void setButtonChangeMouseStates(final List buttonChangeMouseStates ) {
			ObjectHelper.checkNotNull("parameter:buttonChangeMouseStates", buttonChangeMouseStates);
			this.buttonChangeMouseStates = buttonChangeMouseStates;
		}	
		
		/**
		 * This mouseStates is filled with captured mouseStates
		 */
		private List mouseStates;

		public List getMouseStates() {
			ObjectHelper.checkNotNull("field:mouseStates", mouseStates);
			return this.mouseStates;
		}

		protected void setMouseStates(final List mouseStates ) {
			ObjectHelper.checkNotNull("parameter:mouseStates", mouseStates);
			this.mouseStates = mouseStates;
		}	
	}
	
	/**
	 *  A slightly modified watcher that abstracts the need to pump Event objects.
	 */
	class TestMouseWatcher extends MouseWatcher{
		
		public TestMouseWatcher(){
		}
		
		public void click( final boolean leftButton, final boolean middleButton, final boolean rightButton ){
			MouseState mouseState = new MouseState();			
			mouseState.setX( this.getX() );
			mouseState.setY( this.getY() );
			mouseState.setLeftButton( leftButton );
			mouseState.setMiddleButton( middleButton );
			mouseState.setRightButton( rightButton );
		}
		
		public void moveBy( final MouseState mouseState ){
			this.moveBy( mouseState.getX(), mouseState.getY() );
		}
		
		void moveBy( final int x, final int y){
			final int newX = x + this.getX();
			final int newY = y + this.getY();

			MouseState mouseState = new MouseState();			
			mouseState.setX( newX );
			mouseState.setY( newY );
			
			this.setX( newX );
			this.setY( newY );
		
			mouseState.setLeftButton( false );
			mouseState.setMiddleButton( false );
			mouseState.setRightButton( false );	
			
			this.handleMouseMoveEvent( mouseState );
		}
		public void handleMouseMoveEvent( final MouseState mouseState ){
			this.setX( mouseState.getX() );
			this.setY( mouseState.getY() );
			super.handleMouseMoveEvent( mouseState );
		}
		
		public void handleMouseButtonEvent( final MouseState mouseState ){
			super.handleMouseButtonEvent( mouseState );
		}

		public List getEvents(){
			return super.getEvents();
		}
		
		int x;
		
		int getX(){
			return this.x;
		}
		
		void setX( final int x ){
			this.x = x;
		}
		
		int y;
		
		int getY(){
			return this.y;
		}
		
		void setY( final int y ){
			this.y = y;
		}
	}
	/**
	 * This list throws an exception if an attempt is made to add the same object to the list more than twice.
	 */
	class ListWhichDoesntAllowDuplicates extends ArrayList{
		public boolean add( final Object object ){
			final Iterator iterator = this.iterator();
			while( iterator.hasNext() ){
				if( iterator.next() == object ){
					fail( "Attempt to add object more than once to list, object:" + object + ", this: " + this );	
				}
			}
			return super.add( object );
		}
	}
	
	TestMouseWatcher createMouseWatcher(){
		return new TestMouseWatcher();
	}
}
